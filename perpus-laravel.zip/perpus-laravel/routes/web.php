<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\LoanController;
use App\Http\Controllers\StatsController;
use App\Http\Controllers\UserController;
use App\Models\ActivityLog;
use App\Models\Book;
use App\Models\Loan;
use App\Models\User;
use Illuminate\Support\Facades\Route;

Route::get('/', [AttendanceController::class, 'index'])->name('attendance');
Route::post('/attendance', [AttendanceController::class, 'store'])->name('attendance.store');

Route::get('/login', [AuthController::class, 'create'])->name('login');
Route::post('/login', [AuthController::class, 'store'])->name('login.store')->middleware('throttle:5,1');

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', function () {
        $user = request()->user();
        $books = Book::orderBy('title')->get();
        $loans = Loan::with(['book', 'user'])
            ->when(! $user->isAdmin(), fn ($query) => $query->where('user_id', $user->id))
            ->latest()->get();

        $stats = [
            'borrowed' => Loan::where('status', 'dipinjam')->count(),
            'reminders' => Loan::where('status', 'dipinjam')->where('due_at', '<=', today()->addDays(3))->count(),
            'overdue' => Loan::where('status', 'dipinjam')->where('due_at', '<', today())->count(),
            'returned_month' => Loan::where('status', 'dikembalikan')->whereMonth('returned_at', today()->month)->whereYear('returned_at', today()->year)->count(),
        ];

        $reminders = Loan::with(['book', 'user'])
            ->where('status', 'dipinjam')
            ->where('due_at', '<=', today()->addDays(3))
            ->orderBy('due_at')
            ->get();

        $activities = ActivityLog::with('user')->latest()->take(10)->get();

        return view('dashboard', [
            'books' => $books,
            'loans' => $loans,
            'students' => $user->isAdmin() ? User::where('role', 'mahasiswa')->orderBy('name')->get() : collect(),
            'stats' => $stats,
            'reminders' => $reminders,
            'activities' => $activities,
        ]);
    })->name('dashboard');

    Route::get('/books/search', [BookController::class, 'search'])->name('books.search');
    Route::get('/users/search-nim', [UserController::class, 'searchByNim'])->name('users.search-nim');
    Route::get('/stats', [StatsController::class, 'index'])->name('stats');
    Route::get('/admin/books', [AdminController::class, 'booksIndex'])->name('admin.books');
    Route::post('/admin/books', [AdminController::class, 'storeBook'])->name('admin.books.store');
    Route::put('/admin/books/{book}', [AdminController::class, 'updateBook'])->name('admin.books.update');
    Route::get('/admin/students', [AdminController::class, 'studentsIndex'])->name('admin.students');
    Route::post('/admin/students', [AdminController::class, 'storeStudent'])->name('admin.students.store');
    Route::get('/admin/reports', [AdminController::class, 'reportsIndex'])->name('admin.reports');
    Route::get('/admin/reports/export', [AdminController::class, 'exportExcel'])->name('admin.reports.export');
    Route::post('/loans', [LoanController::class, 'store'])->name('loans.store');
    Route::patch('/loans/{loan}/return', [LoanController::class, 'returnBook'])->name('loans.return');
    Route::post('/logout', [AuthController::class, 'destroy'])->name('logout');
});
