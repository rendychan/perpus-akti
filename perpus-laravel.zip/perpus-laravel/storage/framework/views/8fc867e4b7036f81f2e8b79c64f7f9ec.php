<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/webp" href="/akti.webp">
<title>Dashboard | Perpus AKTI</title>
<style>
:root{--maroon-dark:#6B2E2E;--maroon:#8A2529;--maroon-light:#A42631;--cream:#F5F3EE;--white:#ffffff;--gray-50:#f9fafb;--gray-100:#f3f4f6;--gray-200:#e5e7eb;--gray-600:#4b5563;--gray-900:#111827;--green:#10b981;--yellow:#f59e0b;--red:#ef4444}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--gray-50);color:var(--gray-900);line-height:1.6}
header{background:linear-gradient(135deg,var(--maroon-dark) 0%,var(--maroon) 50%,var(--maroon-light) 100%);color:var(--white);padding:20px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 12px rgba(107,46,46,0.15)}
.brand{display:flex;align-items:center;gap:16px}
.brand img{height:48px;width:auto}
.brand-text{display:flex;flex-direction:column}
.brand-text strong{font-size:20px;letter-spacing:0.5px}
.brand-text small{font-size:13px;opacity:0.9}
.header-right{display:flex;align-items:center;gap:24px}
.user-info{text-align:right}
.user-info div:first-child{font-size:14px;font-weight:600}
.user-info div:last-child{font-size:12px;opacity:0.85}
.btn-logout{background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;cursor:pointer;font-weight:600;font-size:14px;transition:all 0.2s}
.btn-logout:hover{background:rgba(255,255,255,0.3)}
main{max-width:1200px;margin:0 auto;padding:32px 24px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:20px;margin-bottom:32px}
.stat-card{background:var(--white);padding:24px;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);border-left:4px solid var(--maroon)}
.stat-card.warning{border-left-color:var(--yellow)}
.stat-card.danger{border-left-color:var(--red)}
.stat-card.success{border-left-color:var(--green)}
.stat-label{font-size:13px;color:var(--gray-600);font-weight:600;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px;display:block}
.stat-value{font-size:36px;font-weight:700;color:var(--gray-900);line-height:1}
.stat-desc{font-size:13px;color:var(--gray-600);margin-top:8px}
.card{background:var(--white);border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);padding:24px;margin-bottom:24px}
.card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px}
.card-title{font-size:18px;font-weight:700;color:var(--gray-900)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:24px;margin-bottom:24px}
.reminder-item{padding:16px;border:1px solid var(--gray-200);border-radius:8px;margin-bottom:12px}
.reminder-item.overdue{border-left:4px solid var(--red);background:rgba(239,68,68,0.05)}
.reminder-item.today{border-left:4px solid var(--yellow);background:rgba(245,158,11,0.05)}
.reminder-header{display:flex;justify-content:space-between;align-items:start;margin-bottom:8px}
.reminder-user{font-weight:600;color:var(--gray-900)}
.reminder-book{font-size:14px;color:var(--gray-600);margin-bottom:4px}
.reminder-due{font-size:13px;font-weight:600}
.reminder-due.overdue{color:var(--red)}
.reminder-due.today{color:var(--yellow)}
.btn-wa{display:inline-flex;align-items:center;gap:6px;background:var(--green);color:var(--white);padding:8px 14px;border-radius:6px;text-decoration:none;font-size:13px;font-weight:600;transition:all 0.2s}
.btn-wa:hover{background:#059669;transform:translateY(-1px)}
.activity-item{padding:12px 0;border-bottom:1px solid var(--gray-200);display:flex;gap:12px}
.activity-item:last-child{border-bottom:none}
.activity-icon{width:36px;height:36px;border-radius:50%;background:var(--gray-100);display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}
.activity-content{flex:1}
.activity-desc{font-size:14px;color:var(--gray-900);margin-bottom:2px}
.activity-time{font-size:12px;color:var(--gray-600)}
.biodata-panel{background:linear-gradient(135deg,#f0fdf4 0%,#dcfce7 100%);border:2px solid var(--green);border-radius:8px;padding:16px;margin-bottom:16px}
.biodata-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:12px}
.biodata-item{display:flex;flex-direction:column}
.biodata-label{font-size:12px;color:var(--gray-600);font-weight:600;text-transform:uppercase;letter-spacing:0.5px}
.biodata-value{font-size:15px;color:var(--gray-900);font-weight:600;margin-top:2px}
label{display:block;font-weight:600;margin-bottom:6px;font-size:14px}
input,select{width:100%;padding:10px;border:1px solid var(--gray-200);border-radius:6px;font-size:14px;margin-bottom:16px}
input:focus,select:focus{outline:none;border-color:var(--maroon);box-shadow:0 0 0 3px rgba(138,37,41,0.1)}
.btn{padding:10px 18px;border:none;border-radius:6px;font-weight:600;font-size:14px;cursor:pointer;transition:all 0.2s}
.btn-primary{background:var(--maroon);color:var(--white)}
.btn-primary:hover{background:var(--maroon-light)}
.btn-secondary{background:var(--gray-200);color:var(--gray-900)}
.btn-secondary:hover{background:var(--gray-300)}
.btn-danger{background:var(--red);color:var(--white)}
.btn-danger:hover{background:#dc2626}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:12px;border-bottom:1px solid var(--gray-200)}
th{background:var(--gray-50);font-weight:600;font-size:13px;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-600)}
.badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600}
.badge-success{background:#d1fae5;color:#065f46}
.badge-warning{background:#fef3c7;color:#92400e}
.badge-danger{background:#fee2e2;color:#991b1b}
.empty{text-align:center;padding:32px;color:var(--gray-600)}
.notice{background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
.error{background:#fee2e2;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
@media(max-width:768px){
header{flex-direction:column;gap:16px;text-align:center}
.header-right{flex-direction:column;width:100%}
.stats{grid-template-columns:1fr}
.grid{grid-template-columns:1fr}
table{font-size:13px}
th,td{padding:8px}
}
</style>
</head>
<body>
<header>
<div class="brand">
<img src="/akti.webp" alt="AKTI">
<div class="brand-text">
<strong>PERPUSTAKAAN AKTI</strong>
<small>Sistem Manajemen Perpustakaan</small>
</div>
</div>
<div class="header-right">
<div class="user-info">
<div><?php echo e(auth()->user()->name); ?></div>
<div><?php echo e(ucfirst(auth()->user()->role)); ?></div>
</div>
<?php if(auth()->user()->isAdmin()): ?>
<a href="<?php echo e(route('admin.books')); ?>" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s">📚 Buku</a>
<a href="<?php echo e(route('admin.students')); ?>" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s">🎓 Mahasiswa</a>
<a href="<?php echo e(route('admin.reports')); ?>" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s">📈 Rekap Bulanan</a>
<a href="<?php echo e(route('attendance')); ?>" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s">📝 Absensi</a>
<a href="<?php echo e(route('stats')); ?>" style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s">📊 Statistik</a>
<?php endif; ?>
<form method="post" action="<?php echo e(route('logout')); ?>">
<?php echo csrf_field(); ?>
<button class="btn-logout">Keluar</button>
</form>
</div>
</header>

<main>
<?php if(session('success')): ?>
<div class="notice"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="error"><?php echo e($errors->first()); ?></div>
<?php endif; ?>

<div class="stats">
<div class="stat-card">
<span class="stat-label">Sedang Dipinjam</span>
<div class="stat-value"><?php echo e($stats['borrowed']); ?></div>
<div class="stat-desc">Buku aktif dipinjam</div>
</div>
<div class="stat-card warning">
<span class="stat-label">Perlu Diingatkan</span>
<div class="stat-value"><?php echo e($stats['reminders']); ?></div>
<div class="stat-desc">Jatuh tempo H-3 atau kurang</div>
</div>
<div class="stat-card danger">
<span class="stat-label">Terlambat</span>
<div class="stat-value"><?php echo e($stats['overdue']); ?></div>
<div class="stat-desc">Melewati jatuh tempo</div>
</div>
<div class="stat-card success">
<span class="stat-label">Kembali Bulan Ini</span>
<div class="stat-value"><?php echo e($stats['returned_month']); ?></div>
<div class="stat-desc"><?php echo e(now()->format('F Y')); ?></div>
</div>
</div>

<?php if(auth()->user()->isAdmin()): ?>
<div class="card">
<div class="card-header">
<h2 class="card-title">🔔 Reminder Jatuh Tempo</h2>
</div>
<div style="max-height:280px;overflow-y:auto;padding-right:4px">
<?php $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$daysLeft = today()->diffInDays($loan->due_at, false);
$isOverdue = $daysLeft < 0;
$isToday = $daysLeft == 0;
$class = $isOverdue ? 'overdue' : ($isToday ? 'today' : '');
?>
<div class="reminder-item <?php echo e($class); ?>">
<div class="reminder-header">
<div>
<div class="reminder-user"><?php echo e($loan->user->name); ?></div>
<div class="reminder-book"><?php echo e($loan->book->title); ?> · <?php echo e($loan->book->code); ?></div>
<div class="reminder-due <?php echo e($class); ?>">
<?php if($isOverdue): ?>
Terlambat <?php echo e(abs($daysLeft)); ?> hari
<?php elseif($isToday): ?>
Jatuh tempo hari ini
<?php else: ?>
<?php echo e($daysLeft); ?> hari lagi
<?php endif; ?>
· <?php echo e($loan->due_at->format('d M Y')); ?>

</div>
</div>
<a href="https://wa.me/<?php echo e(preg_replace('/^0/', '62', $loan->user->phone)); ?>?text=<?php echo e(urlencode('Halo ' . $loan->user->name . ', ini pengingat dari Perpustakaan AKTI. Buku *' . $loan->book->title . '* (' . $loan->book->code . ') yang Anda pinjam ' . ($isOverdue ? 'telah melewati batas pengembalian pada ' : ($isToday ? 'jatuh tempo hari ini ' : 'perlu dikembalikan paling lambat ')) . $loan->due_at->format('d F Y') . '. Mohon kembalikan buku kepada admin perpustakaan. Terima kasih.')); ?>" target="_blank" class="btn-wa">
💬 WhatsApp
</a>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php endif; ?>

<div class="grid">
<?php if(auth()->user()->isAdmin()): ?>
<div class="card">
<div class="card-header">
<h2 class="card-title">➕ Catat Peminjaman</h2>
</div>
<form method="post" action="<?php echo e(route('loans.store')); ?>">
<?php echo csrf_field(); ?>
<label>NIM Mahasiswa <span style="font-weight:normal;font-size:12px">(ketik untuk cari)</span></label>
<input id="nimSearch" autocomplete="off" placeholder="Cari NIM mahasiswa" maxlength="10">
<input id="userId" type="hidden" name="user_id" required>
<div id="biodataPanel" style="display:none"></div>
<label>Nomor WhatsApp <span style="font-weight:normal;font-size:12px">(bisa diedit)</span></label>
<input id="phoneInput" name="phone_override" placeholder="08xx..." maxlength="15">
<label>Tanggal Pinjam</label>
<input type="date" name="borrowed_at" value="<?php echo e(today()->format('Y-m-d')); ?>" max="<?php echo e(today()->format('Y-m-d')); ?>" required>
<label>Buku <span style="font-weight:normal;font-size:12px">(ketik untuk cari)</span></label>
<input id="bookSearch" autocomplete="off" placeholder="Cari judul atau kode buku">
<input id="bookTitle" readonly placeholder="Buku yang dipilih">
<input id="bookId" type="hidden" name="book_id" required>
<div id="searchResults" style="max-height:200px;overflow:auto;margin-bottom:16px"></div>
<button class="btn btn-primary" style="width:100%">Simpan Peminjaman (Jatuh tempo otomatis 14 hari)</button>
</form>
</div>
<?php endif; ?>

<div class="card">
<div class="card-header">
<h2 class="card-title">📋 Log Aktivitas</h2>
</div>
<?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="activity-item">
<div class="activity-icon">📝</div>
<div class="activity-content">
<div class="activity-desc"><?php echo e($activity->description); ?></div>
<div class="activity-time"><?php echo e($activity->user?->name ?? 'System'); ?> · <?php echo e($activity->created_at->diffForHumans()); ?></div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="empty">Belum ada aktivitas</div>
<?php endif; ?>
</div>
</div>

<div class="card">
<div class="card-header">
<h2 class="card-title">📚 Riwayat Peminjaman</h2>
</div>
<table>
<thead>
<tr>
<th>Buku</th>
<th>Peminjam</th>
<th>Pinjam</th>
<th>Jatuh Tempo</th>
<th>Status</th>
<?php if(auth()->user()->isAdmin()): ?>
<th>Aksi</th>
<?php endif; ?>
</tr>
</thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
<td><?php echo e($loan->book->title); ?><br><small style="color:#6b7280"><?php echo e($loan->book->code); ?></small></td>
<td><?php echo e($loan->user->name); ?></td>
<td><?php echo e($loan->borrowed_at->format('d M Y')); ?></td>
<td><?php echo e($loan->due_at->format('d M Y')); ?></td>
<td>
<?php if($loan->status === 'dikembalikan'): ?>
<span class="badge badge-success">Dikembalikan</span>
<?php elseif($loan->due_at < today()): ?>
<span class="badge badge-danger">Terlambat</span>
<?php else: ?>
<span class="badge badge-warning">Dipinjam</span>
<?php endif; ?>
</td>
<?php if(auth()->user()->isAdmin()): ?>
<td>
<?php if($loan->status === 'dipinjam'): ?>
<form method="post" action="<?php echo e(route('loans.return', $loan)); ?>" style="display:inline">
<?php echo csrf_field(); ?>
<?php echo method_field('PATCH'); ?>
<button class="btn btn-danger" style="padding:6px 12px;font-size:13px">Kembalikan</button>
</form>
<?php endif; ?>
</td>
<?php endif; ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="6" class="empty">Belum ada peminjaman</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</main>

<script>
const nimSearch=document.getElementById('nimSearch'),userId=document.getElementById('userId'),biodataPanel=document.getElementById('biodataPanel');
const bookSearch=document.getElementById('bookSearch'),bookResults=document.getElementById('searchResults'),bookId=document.getElementById('bookId'),bookTitle=document.getElementById('bookTitle');

// Auto prefill if redirected from attendance
<?php if(isset($prefillNim) && $prefillNim): ?>
window.addEventListener('DOMContentLoaded', () => {
    if(nimSearch) {
        nimSearch.value = "<?php echo e($prefillNim); ?>";
        nimSearch.dispatchEvent(new Event('input'));
    }
});
<?php endif; ?>

let nimTimer;
nimSearch?.addEventListener('input',()=>{
clearTimeout(nimTimer);
let nim=nimSearch.value.trim();
if(!nim){biodataPanel.style.display='none';biodataPanel.innerHTML='';userId.value='';return}
nimTimer=setTimeout(async()=>{
try{
let res=await fetch(`/users/search-nim?nim=${encodeURIComponent(nim)}`);
if(!res.ok){biodataPanel.style.display='none';biodataPanel.innerHTML='';userId.value='';return}
let user=await res.json();
userId.value=user.id;
document.getElementById('phoneInput').value=user.phone;
biodataPanel.style.display='block';
biodataPanel.innerHTML=`<div class="biodata-panel"><div style="font-size:16px;font-weight:700;color:var(--green);margin-bottom:8px">✓ Mahasiswa Ditemukan</div><div class="biodata-grid"><div class="biodata-item"><span class="biodata-label">Nama Lengkap</span><span class="biodata-value">${user.name}</span></div><div class="biodata-item"><span class="biodata-label">NIM</span><span class="biodata-value">${user.nim}</span></div><div class="biodata-item"><span class="biodata-label">WhatsApp</span><span class="biodata-value">${user.phone}</span></div><div class="biodata-item"><span class="biodata-label">Grup Belajar</span><span class="biodata-value">${user.grup_belajar||'-'}</span></div></div></div>`;
}catch(e){biodataPanel.style.display='none';biodataPanel.innerHTML='';userId.value=''}
},300);
});
let bookTimer;
bookSearch?.addEventListener('input',()=>{
clearTimeout(bookTimer);
let q=bookSearch.value.trim();
if(!q){bookResults.innerHTML='';bookTitle.value='';bookId.value='';return}
bookTimer=setTimeout(async()=>{
let books=await fetch(`/books/search?q=${encodeURIComponent(q)}`).then(r=>r.json());
bookResults.innerHTML=books.length?books.map(b=>`<div style="padding:10px;border:1px solid #e5e7eb;border-radius:6px;margin-bottom:8px;cursor:pointer" data-id="${b.id}" data-title="${b.title.replace(/"/g,'&quot;')}" data-rack="${b.rack_location||''}" onclick="selectBook(this)"><strong>${b.title}</strong><br><small style="color:#6b7280">${b.code} · 📍 ${b.rack_location||'Rak Umum'} · Tersedia ${b.available_stock}</small></div>`).join(''):'<div style="padding:16px;text-align:center;color:#6b7280">Buku tidak ditemukan</div>';
},200);
});
function selectBook(el){
bookId.value=el.dataset.id;
bookTitle.value=el.dataset.title;
bookResults.innerHTML=`<div style="padding:10px;background:#d1fae5;border-radius:6px;color:#065f46">Dipilih: <strong>${el.dataset.title}</strong><br><small>📍 Lokasi: ${el.dataset.rack || 'Belum diatur'}</small></div>`;
}
</script>
</body>
</html>
<?php /**PATH C:\Users\ThinkPad\Documents\Project Perpus\perpus-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>