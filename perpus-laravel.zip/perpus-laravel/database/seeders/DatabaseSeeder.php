<?php

namespace Database\Seeders;

use App\Models\Book;
use App\Models\Category;
use App\Models\User;
use App\Models\Loan;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Admin
        User::create([
            'name' => 'Admin Perpustakaan',
            'email' => 'admin@akti.test',
            'role' => 'admin',
            'password' => Hash::make('password'),
            'phone' => '081200000000',
            'nim' => 'ADMIN01',
            'grup_belajar' => 'Admin',
        ]);

        // Data Mahasiswa Real + Nomor WA Asli
        $studentsData = [
            // TOPKR A
            ['ABDUL AZIS HERMAWAN', '3265301', 'TOPKR A', '083807814548'],
            ['ABDUL RAHMAN AL BARBASI', '3265302', 'TOPKR A', '085700048325'],
            ['AFFAN HIDAYATUR RAKHMAN', '3265303', 'TOPKR A', '0895622402174'],
            ['AGUS SINATRIYA', '3265304', 'TOPKR A', '085865033477'],
            ['AKBAR FEBRIANO PERKASA', '3265305', 'TOPKR A', '089687737834'],
            ['ANDI HERMAWAN', '3265306', 'TOPKR A', '089657616484'],
            ['ANDRA', '3265307', 'TOPKR A', '089504048071'],
            ['AURELIA LUNA FARHANAH', '3265308', 'TOPKR A', '085811168118'],
            ['CAHYO KUSUMA PERMADI', '3265309', 'TOPKR A', '085725011541'],
            ['CATUR MUBAROK', '3265310', 'TOPKR A', '085870957926'],
            ['DEDI IRAWAN', '3265311', 'TOPKR A', '085786462976'],
            ['DIMAS RAMADHAN', '3265312', 'TOPKR A', '085198599580'],
            ['DIMAS SYAHPUTRA', '3265313', 'TOPKR A', '083824018677'],
            ['FAIZ ABDILLAH', '3265314', 'TOPKR A', '085293969359'],
            ['FAJAR RISKI', '3265315', 'TOPKR A', '083174257698'],

            // TOPKR B
            ['FAJAR RIZKI PRATAMA', '3265316', 'TOPKR B', '083185419677'],
            ['FATHURRAHMAN AL GHOZY', '3265317', 'TOPKR B', '083834498725'],
            ['FELIX FEBRIAN HARI PANGESTU', '3265318', 'TOPKR B', '087712606175'],
            ['HAFIS HIBATULLAH', '3265319', 'TOPKR B', '085785815135'],
            ['ILHAM SUCI ANSHORI', '3265320', 'TOPKR B', '085728570468'],
            ['ILHAM YUSUF KHANAFI', '3265321', 'TOPKR B', '082326462573'],
            ['ISYA SYAEFUDDIN TSALAS', '3265322', 'TOPKR B', '089619346038'],
            ['KINANTI DWI PUTRIA', '3265323', 'TOPKR B', '085167921622'],
            ['LISA PUTRIANI', '3265324', 'TOPKR B', '082171590423'],
            ['M. RAFFA ZEIN', '3265338', 'TOPKR B', '089515705243'],
            ['MAHADAYA BISMA PUTRA NUR ISTANTO', '3265325', 'TOPKR B', '085931495489'],
            ['MAHESA ALIF QUROTA AYUN', '3265326', 'TOPKR B', '085824497226'],
            ['MERI MARLIANA', '3265327', 'TOPKR B', '0895421375557'],
            ['MUCH ULINNUHA', '3265328', 'TOPKR B', '08813974105'],
            ['MUHAMAD AVISENNA', '3265329', 'TOPKR B', '081919174615'],

            // TOPKR C
            ['MUHAMAD RAFLI', '3265330', 'TOPKR C', '089652507985'],
            ['MUHAMMAD ADIEB ASSHULTHONI', '3265331', 'TOPKR C', '082374711181'],
            ['MUHAMMAD AMMAR FIRJATULLAH', '3265332', 'TOPKR C', '083897874572'],
            ['MUHAMMAD DAVIN ALFIANSYAH', '3265333', 'TOPKR C', '082320623171'],
            ['MUHAMMAD FAIQ HAIDAR', '3265334', 'TOPKR C', '089696158324'],
            ['MUHAMMAD HARY ADI SYAPUTRA PURBA', '3265335', 'TOPKR C', '082279913600'],
            ['MUHAMMAD HATRAS', '3265336', 'TOPKR C', '0895605453422'],
            ['MUHAMMAD KHAIDAR ALI', '3265337', 'TOPKR C', '085713811248'],
            ['NARASHEVA MAHARDIKA', '3265339', 'TOPKR C', '085161553327'],
            ['NAUFAL ARAFIF APRILIAN', '3265340', 'TOPKR C', '085702708701'],
            ['NAUFAL KHOIRUDIN', '3265341', 'TOPKR C', '085791554911'],
            ['NAYLA AULIA BERLIANA LUKMAN', '3265342', 'TOPKR C', '085801120229'],
            ['NAZWA HANIDA', '3265343', 'TOPKR C', '081289468513'],
            ['PANDU ALFIAN EZRA', '3265344', 'TOPKR C', '089601783149'],
            ['PUTRI ANDINI', '3265345', 'TOPKR C', '085892266850'],

            // TOPKR D
            ['PUTRI APRILIA', '3265346', 'TOPKR D', '085328750232'],
            ['RADJA PUTRA AKMAL MALIKI', '3265347', 'TOPKR D', '082220648361'],
            ['RAFID DAFFA ABIYYU', '3265348', 'TOPKR D', '082225866646'],
            ['RANDY ARYANTO', '3265349', 'TOPKR D', '083846313266'],
            ['REIHAN FADHILAH', '3265350', 'TOPKR D', '085727962082'],
            ['RENDY ARJIYADI SAPUTRA', '3265351', 'TOPKR D', '089503136620'],
            ['REYHAN KURNIAWAN', '3265352', 'TOPKR D', '087865955112'],
            ['RIFQI KHOERUS SAFI', '3265353', 'TOPKR D', '089526369231'],
            ['RIZQI MAULANA', '3265354', 'TOPKR D', '088233083637'],
            ['SINDI YANI', '3265355', 'TOPKR D', '085722778652'],
            ['TARUNA', '3265356', 'TOPKR D', '083101329530'],
            ['TRI SETYANI ANINDITA', '3265357', 'TOPKR D', '087786886497'],
            ['USAMAH', '3265358', 'TOPKR D', '082113084383'],
            ['VAREL MAULANA', '3265359', 'TOPKR D', '085643134571'],
            ['WAHYU AJI SASONGKO', '3265360', 'TOPKR D', '083106379226'],

            // TPMO A
            ['ADRIAN RIZKI ADITIYA', '3265201', 'TPMO A', '0895322972841'],
            ['AHMAD HUMAEDI', '3265202', 'TPMO A', '081511688242'],
            ['AJIE ALAMSYAH', '3265203', 'TPMO A', '085523699525'],
            ['ALLAN YUDHA WIDANARTO', '3265204', 'TPMO A', '0881027231500'],
            ['ANDIK AWALURRIZQI', '3265205', 'TPMO A', '081328146106'],
            ['ANELKA RAHMAT SETYADI', '3265206', 'TPMO A', '082241270548'],
            ['AZKA FAR\'AZ ARHAB', '3265207', 'TPMO A', '085777677086'],
            ['DAFA ADQILA', '3265208', 'TPMO A', '081283842262'],

            // TPMO B
            ['DANI ARDIANSYAH', '3265209', 'TPMO B', '0859106879780'],
            ['DIMAS RIFKI PERMANA', '3265210', 'TPMO B', '081902669591'],
            ['ERLAND AS SAHLAN', '3265211', 'TPMO B', '089673730734'],
            ['FAHMI RIDHO', '3265212', 'TPMO B', '082325915337'],
            ['HASBI NOVA RANDA', '3265213', 'TPMO B', '089502417553'],
            ['HOPI NUROHMAN', '3265214', 'TPMO B', '085786253362'],
            ['ISLA KHOIRONUL IZAZ', '3265215', 'TPMO B', '081249268153'],
            ['JAFAR AS SIDHIQ', '3265216', 'TPMO B', '088233079928'],

            // TPMO C
            ['JAVARA FIRZI NURFAIDHILAH', '3265217', 'TPMO C', '085733414931'],
            ['LUTHFY ASROFUL ANAM', '3265218', 'TPMO C', '088214818820'],
            ['M.RASSYA ADZIKRA', '3265223', 'TPMO C', '085862943027'],
            ['MUHAMAD FADIL ARMAN', '3265219', 'TPMO C', '089604413587'],
            ['MUHAMMAD AGASTYA DHAFA', '3265220', 'TPMO C', '085715449744'],
            ['MUHAMMAD DZAKKI RAMASYAH', '3265221', 'TPMO C', '082113481600'],
            ['MUHAMMAD HAFADZA ALGHIFARY', '3265222', 'TPMO C', '081329074217'],
            ['NURWAHYU UMBARA', '3265224', 'TPMO C', '083878349345'],

            // TPMO D
            ['PAULUS SADHANA KUS DANANG MUSTIKO', '3265225', 'TPMO D', '0895391990437'],
            ['RADIF MUHAMMAD SALMAN', '3265226', 'TPMO D', '085848946154'],
            ['RESTU PRANANDA ADITIYA', '3265227', 'TPMO D', '083841929155'],
            ['REVALDO', '3265228', 'TPMO D', '0881026148311'],
            ['REYHAN ADLI DZAKI HAVILA', '3265229', 'TPMO D', '08993397559'],
            ['RIFKY AL GHOZALI', '3265230', 'TPMO D', '087781529475'],
            ['RISKI SURYA PRATAMA', '3265231', 'TPMO D', '085697875600'],
            ['ZICO BRILIYAN ANDREANO', '3265232', 'TPMO D', '088238591275'],
        ];

        foreach ($studentsData as [$name, $nim, $group, $phone]) {
            User::create([
                'name' => $name,
                'nim' => $nim,
                'phone' => $phone,
                'role' => 'mahasiswa',
                'grup_belajar' => $group,
                'email' => strtolower(str_replace(['.', ' ', "'"], '', $name)) . '@akti.test',
                'password' => Hash::make('password'),
            ]);
        }

        // Categories
        $categories = [
            ['IOT', 'Internet of Things'],
            ['PRO', 'Pemrograman'],
            ['WEB', 'Web Development'],
            ['DB', 'Database'],
            ['ELK', 'Elektronika'],
            ['MGT', 'Manajemen & Kaizen'],
        ];

        foreach ($categories as [$code, $name]) {
            Category::create(compact('code', 'name'));
        }

        // Cleaned Books Data
        $rawBooks = [
            ["Perancangan Sistem Poka-Yoke Berbasis PLC pada Proses Perakitan Engine untuk Mencegah Bolt Connecting Rod Kendor Lolos ke Next Proses", "Anllasosa, Ronggo Gusti"],
            ["Level Up Mekanisme Auto Stopper Empty Slipper Piston", "Pirlo, Dede Andrea"],
            ["Menanggulangi Problem Sensor Stopper Outfeed pada Mesin Automation Transfer Cylinder Block", "Alzamzam, Dwinanda"],
            ["Menaikkan Level QAN pada Proses Pemasangan Crank Cap Subline", "Dzaki, Muhammad Naufal"],
            ["Penerapan Mistake Proofing untuk Mencegah Miss Process pada Block 1 TR di Mesin IGR-045 dan IGR-046 Line Cylinder Block", "Asep Retno Dwi Kusuma"],
            ["Menanggulangi Problem Oil Hole Improper Fault pada Cosmo Leak Tester dengan Membuat Autodrain System", "Kurniawan, Irsyad Shiddiq"],
            ["Modifikasi Lifter Cylinder Block Rough untuk Eliminasi Stuck dan Defect Plant 3 PT TMMIN", "Ahmad, Febian Maulana"],
            ["Transformasi Board 4S Ke Digital Dengan Membuat Visualisasi Power BI", "Saleh, Dino Adrian"],
            ["Meningkatkan Efisiensi Progress Control Jig Pada Aktivitas Function Check Mechanical Dengan Menerapkan Sistem Digital Checksheet", "Widianto, Andi Setya"],
            ["Pengembangan DAX Dalam Power BI Untuk Meningkatkan Kualitas Monitoring Progres Serta Menurunkan Biaya Operasional Administratif Dan Menganalisis Pengaruhnya Terhadap Emisi Karbon Di Departemen EDD Divisi PETD PT TMMIN", "Rofiq, Ahmad Hadi Nur"],
            ["Mencegah Karyawan Melanggar Administrasi Berkendara Melalui Sistem Digital Di Departement Logistic Operational Unit PT. TMMIN Plant 3 Karawang", "Pratama, Andhika Wahyu"],
            ["Mereduce Waktu Proses Repair Defect Sealer Crack Pada Area RR Door Inner Pada Pos 6 & 7 Line Repair Di PT TMMIN Karawang Plant 2", "Rizal, Fikri Ananda"],
            ["Penerapan CVE Unit Monitoring System Untuk Menurunkan Persentase Unit Delay CVE Melebihi 4 Jam", "Syahputra, Rizqi Maulana Dwi"],
            ["Pengembangan Dashboard KPI Tree Safety Berbasis Power Platform Untuk Meningkatkan Efektivitas Pengawasan Keselamatan Kerja", "Fadilah, Zahra Nur"],
            ["Menanggulangi Potensi Tap Pulley Crankshaft Tidak Center Outflow Test Bench & TMMIN Plant 2 Dengan Membuat Presisi Gauge Pada Kamishibai Gate Crankshaft TMMIN Karawang Plant 3", "Dewi, Dian Kartika"],
            ["Menanggulangi Potensi Man Power Terbentur Scanner Airbag Di Pos CS LH CS Line PT. TMMIN Plant 2 Karawang", "Simanjuntak, Kevin Gabriel Yosep"],
            ["Meningkatkan Level Ergonomi Dalam Proses Return Empty Box Di Line SPS & Delivery", "Putra, Rangga Dwi"],
            ["Menurunkan Defect Outflow Saat Proses Inspeksi Area Roof Pada Unit", "Naoval, Ikhwan"],
            ["Menghilangkan Muda Langkah Saat Prepare Part Engine Mounting & Retainer Dengan Metode Karakuri", "Hidayat, Dimas Fanur"],
            ["Menanggulangi Probelm Alumunium Menempel Pada Proses Coating Dengan Metode Masking Spray Pada Die Ireko Front Line Die Maintenance", "Rohman, Muhammad Dani Nur"],
            ["Dunia Menurut Fisika", "Al-Khalili, Jim"],
            ["Tingkatkan Profit Trading dengan ChatGPT", "L., Anthony"],
            ["Buku Sakti Pemrograman Web : HTML, CSS, PHP, MySQL & JavaScript", "Setiawan, Didik"],
            ["Gampang Menguasai Microsoft Word 2010", "Istiana, Dyah ; Wati, Mardiana"],
            ["Rahasia Berbisnis Ala Sosial Media", "Sulianta, Feri"],
            ["visual basic untuk pemula", "Wibowo, Sastya Hendri ; Handhayani, Tien Surfa"],
            ["Gampang Menguasai Microsoft PowerPoint 2010", "Istiana, Dyah ; Wati, Mardiana"],
            ["Kunci Sukses Visual FoxPro 6.0", "Pramana, Hengky W."],
            ["Komputer Animasi dengan 3D Studio Max", "Ekomadyo, Agus S. ; K., M. Donny ; W., Robert Rianto"],
            ["Teknologi Terintegrasi: Mobile Development, Komputasi Awan, dan Pembelajaran Mesin", "Khairani, Dewi; Marzuki Shofi, Imam; Aripiyanto, Saepul"],
            ["Pengenalan Machine Learning dengan Python", "Kurniawan, Dios"],
            ["Tips & Tricks: AutoCAD 3D Modeling for Industry", "Soma, Hari Aria"],
            ["Menyiasati Krisis Ekonomi: Kiat Investasi & Penyelamatan Aset", "Teamwork, Medpress"],
            ["Seni Merancang dengan AutoCAD", "Gunadi, FX Sutiono"],
            ["Kupas Tuntas Microsoft Word 2013", "MADCOMS"],
            ["Step by Step Pintar dan Mahir Microsoft Office 2010", "Asiah, Neneng ; Suhendi, Edi"],
            ["Elektronika Praktis: Panduan Penghobi, Pengembang Software, dan Entrepreneur", "Budiharto, Widodo"],
            ["Buku Pintar Pemrograman Arduino", "Kadir, Abdul"],
            ["Pemrograman Arduino untuk Agrikultur dan Smart Farming", "Budiharto, Widodo; Suhartono, Derwin"],
            ["Akselerasi Teknologi Informasi: Cakap dan Beretika di Era Digital", "Athoillah, Muhammad; Hastuti, Dwi"],
            ["Attitude is Everything : Sikap Mental Adalah Segalanya", "Keller, Jeff"],
            ["MasterCAM 2018 : Buku Belajar – Mill-3(2D)", "Adiwibowo, B. Triwahyu"],
            ["Membuat desain web dengan Javascript", "Erhans, A."],
            ["Microsoft Office 2013", "Wahana Komputer"],
            ["Ubuntu Linux Unleashed 2021 Edition", "Helmke, Matthew"],
            ["Pengantar Komputer : Dasar Ilmu Komputer, Pemrograman", "Hartono, Jogiyanto"],
            ["Beginning Linux Programming", "Matthew, Neil; Stones, Richard"],
            ["Data Mining dan Machine Learning Menggunakan MATLAB dan Python", "Handayanto, Rahmadya Trias; Herlawati"],
            ["Fundamental Photoshop 5", "Greenberg, Adele Droblas; Greenberg, Seth"],
            ["Simulasi Sistem Otomasi Industri Menggunakan Factory I/O", "Andriana, Zulkarnain, Rianza Fauzi"],
            ["Pemrograman Python untuk Pemula", "Winardi, Sugeng"],
            ["Pengantar Ilmu Perpustakaan", "Basuki, Sulistyo"],
            ["Software Engineering: A Practitioner's Approach", "Pressman, Roger S."],
            ["Manajemen Perawatan Industri Teknik dan Aplikasi (TPM)", "Kurniawan, Fajar"],
            ["Total Quality Management", "Tjiptono, Fandy; Diana, Anastasia"],
            ["Manajemen Operasional Strategi dan Analisa", "Deitiana, Tita"],
            ["Sikap Kerja 5S", "Osada, Takashi"],
            ["Lean Manufacturing: Langkah Pengurangan Pemborosan Dalam Produksi", "Rosyidah, Masayu; Ismariani, Rosi"],
            ["The Machine That Changed the World (Lean Production)", "Womack, James P. ; Jones, Daniel T. ; Roos, Daniel"],
        ];

        $catIds = Category::pluck('id')->toArray();
        $racks = ['Rak A-01', 'Rak A-02', 'Rak B-01', 'Rak B-02', 'Rak C-01', 'Rak C-02', 'Rak D-01', 'Rak D-02'];

        foreach ($rawBooks as $index => [$title, $author]) {
            $code = 'BK-' . str_pad($index + 1, 3, '0', STR_PAD_LEFT);
            $stock = rand(2, 6);
            Book::create([
                'code' => $code,
                'title' => $title,
                'author' => $author,
                'stock' => $stock,
                'available_stock' => $stock,
                'category_id' => $catIds[array_rand($catIds)],
                'rack_location' => $racks[array_rand($racks)],
            ]);
        }

        // Sample Loans for Statistics Ranking
        $students = User::where('role', 'mahasiswa')->get();
        $allBooks = Book::all();
        $today = today();

        // Top student: Abdul Azis Hermawan (3265301)
        $topStudent = $students->where('nim', '3265301')->first();
        if ($topStudent) {
            foreach (range(1, 15) as $i) {
                Loan::create([
                    'user_id' => $topStudent->id,
                    'book_id' => $allBooks->random()->id,
                    'borrowed_at' => $today->copy()->subDays(rand(5, 30)),
                    'due_at' => $today->addDays(rand(-5, 10)),
                    'status' => 'dikembalikan',
                    'returned_at' => $today->subDays(rand(1, 5)),
                ]);
            }
        }

        // Random loans for other students
        foreach (range(1, 60) as $i) {
            $st = $students->random();
            $bk = $allBooks->random();
            $borrowedAt = $today->copy()->subDays(rand(1, 25));
            $status = rand(0, 1) ? 'dikembalikan' : 'dipinjam';

            Loan::create([
                'user_id' => $st->id,
                'book_id' => $bk->id,
                'borrowed_at' => $borrowedAt,
                'due_at' => $borrowedAt->copy()->addDays(14),
                'status' => $status,
                'returned_at' => $status === 'dikembalikan' ? $borrowedAt->copy()->addDays(rand(1, 10)) : null,
            ]);

            if ($status === 'dipinjam' && $bk->available_stock > 0) {
                $bk->decrement('available_stock');
            }
        }

        // Reminder sample: Abdul Rahman (3265302) - Overdue
        $lateStudent = $students->where('nim', '3265302')->first();
        $lateBook = $allBooks->first();
        if ($lateStudent && $lateBook) {
            Loan::create([
                'user_id' => $lateStudent->id,
                'book_id' => $lateBook->id,
                'borrowed_at' => $today->copy()->subDays(20),
                'due_at' => $today->copy()->subDays(5),
                'status' => 'dipinjam',
            ]);
            if ($lateBook->available_stock > 0) {
                $lateBook->decrement('available_stock');
            }
        }
    }
}
