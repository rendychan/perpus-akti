<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function search(Request $request)
    {
        $query = trim((string) $request->query('q'));

        if ($query === '') {
            return response()->json([]);
        }

        return response()->json(Book::query()
            ->where('title', 'like', "%{$query}%")
            ->orWhere('code', 'like', "%{$query}%")
            ->orderBy('title')
            ->limit(8)
            ->get(['id', 'code', 'title', 'author', 'rack_location', 'available_stock']));
    }
}
