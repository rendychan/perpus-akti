<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Book;
use App\Models\Loan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LoanController extends Controller
{
    public function publicCreate(Request $request)
    {
        $nim = $request->query('nim');
        $student = $nim ? User::where('nim', $nim)->first() : null;
        $books = Book::orderBy('title')->get();
        return view('borrow', compact('student', 'books'));
    }

    public function publicStore(Request $request)
    {
        $validated = $request->validate([
            'user_id' => ['required', 'exists:users,id'],
            'book_id' => ['required', 'exists:books,id'],
        ]);

        $student = User::findOrFail($validated['user_id']);
        $book = Book::findOrFail($validated['book_id']);

        if ($book->available_stock > 0) {
            DB::transaction(function () use ($book, $student) {
                Loan::create([
                    'user_id' => $student->id,
                    'book_id' => $book->id,
                    'borrowed_at' => today(),
                    'due_at' => today()->addDays(14),
                    'status' => 'dipinjam',
                ]);
                $book->decrement('available_stock');
                ActivityLog::log('peminjaman_mandiri', "Peminjaman mandiri buku {$book->title} oleh {$student->name}", ['book_id' => $book->id, 'user_id' => $student->id]);
            });
            return redirect()->route('attendance')->with('success', "Peminjaman buku '{$book->title}' berhasil dicatat untuk {$student->name}. Jatuh tempo 14 hari.");
        }

        return back()->withErrors(['book_id' => 'Stok buku habis.']);
    }

    public function returnBook(Request $request, Loan $loan)
    {
        abort_unless($request->user()->isAdmin(), 403);
        if ($loan->status === 'dipinjam') {
            DB::transaction(function () use ($loan) {
                $loan->update(['status' => 'dikembalikan', 'returned_at' => today()]);
                $loan->book()->increment('available_stock');
                ActivityLog::log('pengembalian', "Mengembalikan buku {$loan->book->title} dari {$loan->user->name}", ['loan_id' => $loan->id]);
            });
        }
        return back()->with('success', 'Buku sudah dikembalikan.');
    }
}
