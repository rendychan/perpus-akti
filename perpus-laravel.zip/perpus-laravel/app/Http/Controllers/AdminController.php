<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use App\Models\User;
use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Loan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function booksIndex(Request $request)
    {
        abort_unless(auth()->user()->isAdmin(), 403);
        $rack = $request->query('rack');
        $books = Book::with('category')
            ->when($rack, fn($q) => $q->where('rack_location', $rack))
            ->latest()
            ->get();
        $categories = Category::all();
        $racks = Book::whereNotNull('rack_location')->distinct()->pluck('rack_location');
        return view('admin.books', compact('books', 'categories', 'racks', 'rack'));
    }

    public function updateBook(Request $request, Book $book)
    {
        abort_unless(auth()->user()->isAdmin(), 403);
        $validated = $request->validate([
            'code' => 'required|unique:books,code,' . $book->id,
            'title' => 'required|string|max:255',
            'author' => 'nullable|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'rack_location' => 'nullable|string|max:50',
            'stock' => 'required|integer|min:1',
        ]);

        $diff = $validated['stock'] - $book->stock;
        $validated['available_stock'] = max(0, $book->available_stock + $diff);
        
        $book->update($validated);

        ActivityLog::log('edit_buku', "Mengubah data buku: {$book->title} ({$book->code})", ['book_id' => $book->id]);

        return back()->with('success', 'Data buku berhasil diperbarui.');
    }

    public function storeBook(Request $request)
    {
        abort_unless(auth()->user()->isAdmin(), 403);
        $validated = $request->validate([
            'code' => 'required|unique:books,code',
            'title' => 'required|string|max:255',
            'author' => 'nullable|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'rack_location' => 'nullable|string|max:50',
            'stock' => 'required|integer|min:1',
        ]);

        $validated['available_stock'] = $validated['stock'];
        $book = Book::create($validated);

        ActivityLog::log('tambah_buku', "Menambahkan buku baru: {$book->title} ({$book->code})", ['book_id' => $book->id]);

        return back()->with('success', 'Buku berhasil ditambahkan.');
    }

    public function studentsIndex()
    {
        abort_unless(auth()->user()->isAdmin(), 403);
        $students = User::where('role', 'mahasiswa')->latest()->get();
        return view('admin.students', compact('students'));
    }

    public function storeStudent(Request $request)
    {
        abort_unless(auth()->user()->isAdmin(), 403);
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'nim' => 'required|unique:users,nim|max:20',
            'phone' => 'required|string|max:20',
            'grup_belajar' => 'nullable|string|max:50',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6',
        ]);

        $validated['role'] = 'mahasiswa';
        $validated['password'] = Hash::make($validated['password']);
        $student = User::create($validated);

        ActivityLog::log('tambah_mahasiswa', "Menambahkan mahasiswa baru: {$student->name} (NIM: {$student->nim})", ['user_id' => $student->id]);

        return back()->with('success', 'Mahasiswa berhasil ditambahkan.');
    }

    public function reportsIndex(Request $request)
    {
        abort_unless(auth()->user()->isAdmin(), 403);
        
        $month = $request->query('month', date('m'));
        $year = $request->query('year', date('Y'));
        $type = $request->query('type', 'attendance');

        if ($type === 'loans') {
            $data = Loan::with(['user', 'book'])
                ->whereMonth('borrowed_at', $month)
                ->whereYear('borrowed_at', $year)
                ->latest()
                ->get();
        } else {
            $data = Attendance::with('user')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->latest()
                ->get();
        }

        return view('admin.reports', compact('data', 'month', 'year', 'type'));
    }

    public function exportExcel(Request $request)
    {
        abort_unless(auth()->user()->isAdmin(), 403);

        $month = $request->query('month', date('m'));
        $year = $request->query('year', date('Y'));
        $type = $request->query('type', 'attendance');

        $fileName = "rekap_{$type}_{$year}_{$month}.csv";
        
        $headers = [
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        ];

        if ($type === 'loans') {
            $records = Loan::with(['user', 'book'])
                ->whereMonth('borrowed_at', $month)
                ->whereYear('borrowed_at', $year)
                ->get();

            $callback = function() use ($records) {
                $file = fopen('php://output', 'w');
                fputcsv($file, ['ID', 'Nama Mahasiswa', 'NIM', 'Grup', 'Kode Buku', 'Judul Buku', 'Tanggal Pinjam', 'Jatuh Tempo', 'Status']);

                foreach ($records as $row) {
                    fputcsv($file, [
                        $row->id,
                        $row->user->name ?? '-',
                        $row->user->nim ?? '-',
                        $row->user->grup_belajar ?? '-',
                        $row->book->code ?? '-',
                        $row->book->title ?? '-',
                        $row->borrowed_at->format('Y-m-d'),
                        $row->due_at->format('Y-m-d'),
                        ucfirst($row->status)
                    ]);
                }
                fclose($file);
            };
        } else {
            $records = Attendance::with('user')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->get();

            $callback = function() use ($records) {
                $file = fopen('php://output', 'w');
                fputcsv($file, ['ID', 'Waktu Kunjungan', 'Nama Mahasiswa', 'NIM', 'Grup Belajar', 'Tujuan Kunjungan']);

                foreach ($records as $row) {
                    fputcsv($file, [
                        $row->id,
                        $row->created_at->format('Y-m-d H:i:s'),
                        $row->user->name ?? '-',
                        $row->user->nim ?? '-',
                        $row->user->grup_belajar ?? '-',
                        $row->purpose
                    ]);
                }
                fclose($file);
            };
        }

        return response()->stream($callback, 200, $headers);
    }
}
