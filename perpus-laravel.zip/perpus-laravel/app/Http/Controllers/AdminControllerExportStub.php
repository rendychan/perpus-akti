<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use App\Models\Loan;
use App\Models\User;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    // ... (kode sebelumnya tetap aman)

    public function reportsIndex(Request $request)
    {
        abort_unless(auth()->user()->isAdmin(), 403);
        
        $month = $request->query('month', date('m'));
        $year = $request->query('year', date('Y'));
        $type = $request->query('type', 'attendance'); // attendance atau loans

        if ($type === 'loans') {
            $data = Loan::with(['user', 'book'])
                ->whereMonth('borrowed_at', $month)
                ->whereYear('borrowed_at', $year)
                ->latest()
                ->get();
        } else {
            $data = Attendance::with('user')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->latest()
                ->get();
        }

        return view('admin.reports', compact('data', 'month', 'year', 'type'));
    }

    public function exportExcel(Request $request)
    {
        abort_unless(auth()->user()->isAdmin(), 403);

        $month = $request->query('month', date('m'));
        $year = $request->query('year', date('Y'));
        $type = $request->query('type', 'attendance');

        $fileName = "rekap_{$type}_{$year}_{$month}.csv";
        
        $headers = [
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        ];

        if ($type === 'loans') {
            $records = Loan::with(['user', 'book'])
                ->whereMonth('borrowed_at', $month)
                ->whereYear('borrowed_at', $year)
                ->get();

            $callback = function() use ($records) {
                $file = fopen('php://output', 'w');
                fputcsv($file, ['ID', 'Nama Mahasiswa', 'NIM', 'Grup', 'Kode Buku', 'Judul Buku', 'Tanggal Pinjam', 'Jatuh Tempo', 'Status']);

                foreach ($records as $row) {
                    fputcsv($file, [
                        $row->id,
                        $row->user->name ?? '-',
                        $row->user->nim ?? '-',
                        $row->user->grup_belajar ?? '-',
                        $row->book->code ?? '-',
                        $row->book->title ?? '-',
                        $row->borrowed_at->format('Y-m-d'),
                        $row->due_at->format('Y-m-d'),
                        ucfirst($row->status)
                    ]);
                }
                fclose($file);
            };
        } else {
            $records = Attendance::with('user')
                ->whereMonth('created_at', $month)
                ->whereYear('created_at', $year)
                ->get();

            $callback = function() use ($records) {
                $file = fopen('php://output', 'w');
                fputcsv($file, ['ID', 'Waktu Kunjungan', 'Nama Mahasiswa', 'NIM', 'Grup Belajar', 'Tujuan Kunjungan']);

                foreach ($records as $row) {
                    fputcsv($file, [
                        $row->id,
                        $row->created_at->format('Y-m-d H:i:s'),
                        $row->user->name ?? '-',
                        $row->user->nim ?? '-',
                        $row->user->grup_belajar ?? '-',
                        $row->purpose
                    ]);
                }
                fclose($file);
            };
        }

        return response()->stream($callback, 200, $headers);
    }
}
