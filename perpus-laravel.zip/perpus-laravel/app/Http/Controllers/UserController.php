<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function searchByNim(Request $request)
    {
        $nim = trim((string) $request->query('nim'));
        
        if ($nim === '') {
            return response()->json(['error' => 'NIM kosong'], 400);
        }

        $user = User::where('nim', $nim)->where('role', 'mahasiswa')->first();

        if (! $user) {
            return response()->json(['error' => 'Mahasiswa tidak ditemukan'], 404);
        }

        return response()->json([
            'id' => $user->id,
            'name' => $user->name,
            'nim' => $user->nim,
            'phone' => $user->phone,
            'grup_belajar' => $user->grup_belajar,
            'email' => $user->email,
        ]);
    }
}
