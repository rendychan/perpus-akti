<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Loan;
use App\Models\User;
use App\Models\Book;
use App\Models\Attendance;
use Illuminate\Support\Facades\DB;

class StatsController extends Controller
{
    public function index()
    {
        // Top 5 mahasiswa paling banyak pinjam
        $topBorrowers = User::where('role', 'mahasiswa')
            ->get()
            ->map(function($user) {
                $user->loans_count = $user->loans()->whereIn('status', ['dipinjam', 'dikembalikan'])->count();
                return $user;
            })
            ->filter(fn($user) => $user->loans_count > 0)
            ->sortByDesc('loans_count')
            ->take(5);

        // Top 5 mahasiswa sering berkunjung
        $topVisitors = User::where('role', 'mahasiswa')
            ->get()
            ->map(function($user) {
                $user->visits_count = Attendance::where('user_id', $user->id)->count();
                return $user;
            })
            ->filter(fn($user) => $user->visits_count > 0)
            ->sortByDesc('visits_count')
            ->take(5);

        // Top 5 buku paling sering dipinjam
        $topBooks = Book::all()
            ->map(function($book) {
                $book->loans_count = $book->loans()->count();
                return $book;
            })
            ->filter(fn($book) => $book->loans_count > 0)
            ->sortByDesc('loans_count')
            ->take(5);

        // Tema/kategori paling diminati (dari tabel categories - 3NF)
        $themes = Category::select('categories.*')
            ->selectRaw('(SELECT COUNT(*) FROM loans JOIN books ON loans.book_id = books.id WHERE books.category_id = categories.id) as loans_count')
            ->get()
            ->filter(fn($cat) => $cat->loans_count > 0)
            ->sortByDesc('loans_count');

        return view('stats', [
            'topBorrowers' => $topBorrowers,
            'topVisitors' => $topVisitors,
            'topBooks' => $topBooks,
            'themes' => $themes,
        ]);
    }
}
