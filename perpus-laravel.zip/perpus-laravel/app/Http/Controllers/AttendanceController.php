<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use App\Models\ActivityLog;
use App\Models\User;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function index()
    {
        $attendances = Attendance::with('user')->latest()->take(50)->get();
        return view('attendance', compact('attendances'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nim' => 'required|exists:users,nim',
            'purpose' => 'required|string|max:255',
        ]);

        $student = User::where('nim', $validated['nim'])->firstOrFail();

        Attendance::create([
            'user_id' => $student->id,
            'purpose' => $validated['purpose'],
        ]);

        ActivityLog::create([
            'user_id' => $student->id,
            'action' => 'kunjungan',
            'description' => "{$student->name} (NIM: {$student->nim}) check-in dengan tujuan: {$validated['purpose']}",
        ]);

        return back()->with('success', "Absensi kunjungan berhasil dicatat untuk: {$student->name} ({$student->nim})");
    }
}
