<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    protected $fillable = ['code', 'title', 'author', 'rack_location', 'stock', 'available_stock', 'category_id'];

    public function loans()
    {
        return $this->hasMany(Loan::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }
}
