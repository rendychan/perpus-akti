<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/webp" href="/akti.webp">
<title>Statistik & Analisis | Perpus AKTI</title>
<style>
:root{--maroon-dark:#6B2E2E;--maroon:#8A2529;--maroon-light:#A42631;--white:#ffffff;--gray-50:#f9fafb;--gray-100:#f3f4f6;--gray-200:#e5e7eb;--gray-600:#4b5563;--gray-900:#111827;--green:#10b981;--blue:#3b82f6;--purple:#8b5cf6}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--gray-50);color:var(--gray-900);line-height:1.6}
header{background:linear-gradient(135deg,var(--maroon-dark) 0%,var(--maroon) 50%,var(--maroon-light) 100%);color:var(--white);padding:20px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 12px rgba(107,46,46,0.15)}
.brand{display:flex;align-items:center;gap:16px}
.brand img{height:48px;width:auto}
.brand-text{display:flex;flex-direction:column}
.brand-text strong{font-size:20px;letter-spacing:0.5px}
.brand-text small{font-size:13px;opacity:0.9}
.header-right{display:flex;align-items:center;gap:24px}
.btn-back{background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s}
.btn-back:hover{background:rgba(255,255,255,0.3)}
main{max-width:1200px;margin:0 auto;padding:32px 24px}
.page-title{font-size:28px;font-weight:700;margin-bottom:32px;color:var(--gray-900)}
.card{background:var(--white);border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);padding:24px;margin-bottom:24px}
.card-header{display:flex;align-items:center;gap:12px;margin-bottom:20px}
.card-icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px}
.card-icon.blue{background:linear-gradient(135deg,#3b82f6,#2563eb)}
.card-icon.green{background:linear-gradient(135deg,#10b981,#059669)}
.card-icon.purple{background:linear-gradient(135deg,#8b5cf6,#7c3aed)}
.card-title{font-size:18px;font-weight:700;color:var(--gray-900)}
.rank-list{display:flex;flex-direction:column;gap:12px}
.rank-item{display:flex;align-items:center;gap:12px;padding:12px;border:1px solid var(--gray-200);border-radius:8px;transition:all 0.2s}
.rank-item:hover{background:var(--gray-50);border-color:var(--maroon)}
.rank-number{width:32px;height:32px;border-radius:50%;background:var(--gray-100);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0}
.rank-item:nth-child(1) .rank-number{background:linear-gradient(135deg,#fbbf24,#f59e0b);color:var(--white)}
.rank-item:nth-child(2) .rank-number{background:linear-gradient(135deg,#94a3b8,#64748b);color:var(--white)}
.rank-item:nth-child(3) .rank-number{background:linear-gradient(135deg,#fb923c,#ea580c);color:var(--white)}
.rank-content{flex:1}
.rank-name{font-weight:600;color:var(--gray-900);margin-bottom:2px}
.rank-meta{font-size:13px;color:var(--gray-600)}
.rank-count{font-size:20px;font-weight:700;color:var(--maroon)}
.theme-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px}
.theme-card{padding:16px;border:2px solid var(--gray-200);border-radius:8px;text-align:center;transition:all 0.2s}
.theme-card:hover{border-color:var(--maroon);transform:translateY(-2px)}
.theme-name{font-weight:600;color:var(--gray-900);margin-bottom:8px}
.theme-count{font-size:32px;font-weight:700;color:var(--maroon)}
.theme-label{font-size:12px;color:var(--gray-600);text-transform:uppercase;letter-spacing:0.5px}
.empty{text-align:center;padding:48px;color:var(--gray-600);font-size:16px}
@media(max-width:768px){
header{flex-direction:column;gap:16px;text-align:center}
.page-title{font-size:22px}
.theme-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>
<header>
<div class="brand">
<img src="/akti.webp" alt="AKTI">
<div class="brand-text">
<strong>PERPUSTAKAAN AKTI</strong>
<small>Statistik & Analisis</small>
</div>
</div>
<div class="header-right">
<a href="{{ route('dashboard') }}" class="btn-back">← Kembali</a>
</div>
</header>

<main>
<h1 class="page-title">📊 Statistik & Analisis Perpustakaan</h1>

<div class="card">
<div class="card-header">
<div class="card-icon blue">🏆</div>
<h2 class="card-title">Top 10 Mahasiswa Paling Banyak Meminjam</h2>
</div>
<div class="rank-list">
@forelse($topBorrowers as $index => $borrower)
<div class="rank-item">
<div class="rank-number">{{ $index + 1 }}</div>
<div class="rank-content">
<div class="rank-name">{{ $borrower->name }}</div>
<div class="rank-meta">NIM: {{ $borrower->nim }} • {{ $borrower->grup_belajar ?? '-' }}</div>
</div>
<div class="rank-count">{{ $borrower->loans_count }}</div>
</div>
@empty
<div class="empty">Belum ada data peminjaman</div>
@endforelse
</div>
</div>

<div class="card">
<div class="card-header">
<div class="card-icon green">📚</div>
<h2 class="card-title">Top 10 Buku Paling Sering Dipinjam</h2>
</div>
<div class="rank-list">
@forelse($topBooks as $index => $book)
<div class="rank-item">
<div class="rank-number">{{ $index + 1 }}</div>
<div class="rank-content">
<div class="rank-name">{{ $book->title }}</div>
<div class="rank-meta">{{ $book->code }} • {{ $book->author }}</div>
</div>
<div class="rank-count">{{ $book->loans_count }}</div>
</div>
@empty
<div class="empty">Belum ada data peminjaman</div>
@endforelse
</div>
</div>

<div class="card">
<div class="card-header">
<div class="card-icon purple">🎯</div>
<h2 class="card-title">Tema/Kategori Paling Diminati</h2>
</div>
<div class="theme-grid">
@forelse($themes as $theme)
<div class="theme-card">
<div class="theme-name">{{ $theme->name }}</div>
<div class="theme-count">{{ $theme->loans_count }}</div>
<div class="theme-label">Peminjaman</div>
</div>
@empty
<div class="empty">Belum ada data peminjaman</div>
@endforelse
</div>
</div>
</main>
</body>
</html>
