<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/webp" href="/akti.webp">
<title>Form Peminjaman Mandiri | Perpus AKTI</title>
<style>
:root{--maroon-dark:#6B2E2E;--maroon:#8A2529;--maroon-light:#A42631;--white:#ffffff;--gray-50:#f9fafb;--gray-100:#f3f4f6;--gray-200:#e5e7eb;--gray-600:#4b5563;--gray-900:#111827;--green:#10b981}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--gray-50);color:var(--gray-900);line-height:1.6}
header{background:linear-gradient(135deg,var(--maroon-dark) 0%,var(--maroon) 50%,var(--maroon-light) 100%);color:var(--white);padding:20px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 12px rgba(107,46,46,0.15)}
.brand{display:flex;align-items:center;gap:16px}
.brand img{height:48px;width:auto}
.brand-text{display:flex;flex-direction:column}
.brand-text strong{font-size:20px;letter-spacing:0.5px}
.brand-text small{font-size:13px;opacity:0.9}
.header-right{display:flex;align-items:center;gap:16px}
.btn-back{background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s}
.btn-back:hover{background:rgba(255,255,255,0.3)}
main{max-width:800px;margin:0 auto;padding:32px 24px}
.card{background:var(--white);border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);padding:32px;margin-bottom:24px}
.card-header{display:flex;align-items:center;gap:12px;margin-bottom:24px}
.card-title{font-size:22px;font-weight:700;color:var(--gray-900)}
label{display:block;font-weight:600;margin-bottom:8px;font-size:15px}
input,select{width:100%;padding:12px;border:1px solid var(--gray-200);border-radius:6px;font-size:15px;margin-bottom:20px}
input:focus,select:focus{outline:none;border-color:var(--maroon);box-shadow:0 0 0 3px rgba(138,37,41,0.1)}
.btn{padding:14px 20px;border:none;border-radius:6px;font-weight:600;font-size:16px;cursor:pointer;transition:all 0.2s;width:100%}
.btn-primary{background:var(--maroon);color:var(--white)}
.btn-primary:hover{background:var(--maroon-light)}
.notice{background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
.error{background:#fee2e2;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
.student-box{background:#f0fdf4;border:2px solid #10b981;border-radius:8px;padding:16px;margin-bottom:20px}
</style>
</head>
<body>
<header>
<div class="brand">
<img src="/akti.webp" alt="AKTI">
<div class="brand-text">
<strong>PERPUSTAKAAN AKTI</strong>
<small>Peminjaman Mandiri</small>
</div>
</div>
<div class="header-right">
<a href="{{ route('attendance') }}" class="btn-back">← Selesai / Kembali</a>
</div>
</header>

<main>
<div class="card">
<div class="card-header">
<h2 class="card-title">📖 Form Peminjaman Buku Mandiri</h2>
</div>

@if(session('success'))
<div class="notice">{{ session('success') }}</div>
@endif
@if($errors->any())
<div class="error">{{ $errors->first() }}</div>
@endif

@if($student)
<div class="student-box">
<div style="font-size:16px;font-weight:700;color:#065f46;margin-bottom:4px">✓ Mahasiswa Terverifikasi</div>
<div><strong>Nama:</strong> {{ $student->name }}</div>
<div><strong>NIM:</strong> {{ $student->nim }} • <strong>Grup:</strong> {{ $student->grup_belajar ?? '-' }}</div>
<div><strong>WhatsApp:</strong> {{ $student->phone }}</div>
</div>

<form method="post" action="{{ route('borrow.store') }}">
@csrf
<input type="hidden" name="user_id" value="{{ $student->id }}">

<label>Cari & Pilih Buku</label>
<input id="bookSearch" autocomplete="off" placeholder="Ketik judul atau kode buku...">
<input id="bookTitle" readonly placeholder="Buku yang dipilih..." style="background:#f3f4f6">
<input id="bookId" type="hidden" name="book_id" required>
<div id="searchResults" style="max-height:200px;overflow:auto;margin-bottom:20px"></div>

<div style="background:#fef3c7;border:1px solid #f59e0b;padding:12px;border-radius:6px;margin-bottom:20px;font-size:14px;color:#92400e">
ℹ️ <strong>Ketentuan Peminjaman:</strong> Masa pinjam buku adalah <strong>14 hari</strong> terhitung sejak hari ini. Pastikan mengembalikan tepat waktu!
</div>

<button class="btn btn-primary">Konfirmasi Peminjaman Buku</button>
</form>
@else
<div class="error">Data mahasiswa tidak ditemukan. Silakan ulangi proses absensi di depan pintu.</div>
<a href="{{ route('attendance') }}" class="btn btn-primary" style="text-align:center;text-decoration:none;display:block">Kembali ke Buku Tamu</a>
@endif
</div>
</main>

<script>
const bookSearch=document.getElementById('bookSearch'),searchResults=document.getElementById('searchResults'),bookId=document.getElementById('bookId'),bookTitle=document.getElementById('bookTitle');
let t;
bookSearch?.addEventListener('input',()=>{
clearTimeout(t);
let q=bookSearch.value.trim();
if(!q){searchResults.innerHTML='';return;}
t=setTimeout(async()=>{
let books=await fetch(`/books/search?q=${encodeURIComponent(q)}`).then(r=>r.json());
searchResults.innerHTML=books.length?books.map(b=>`<div style="padding:10px;border:1px solid #e5e7eb;border-radius:6px;margin-bottom:8px;cursor:pointer;background:#fff" data-id="${b.id}" data-title="${b.title.replace(/"/g,'&quot;')}" onclick="selectBook(this)"><strong>${b.title}</strong><br><small style="color:#6b7280">${b.code} · 📍 ${b.rack_location||'Rak Umum'} · Tersedia: ${b.available_stock}</small></div>`).join(''):'<div style="padding:16px;text-align:center;color:#6b7280">Buku tidak ditemukan</div>';
},200);
});
function selectBook(el){
bookId.value=el.dataset.id;
bookTitle.value=el.dataset.title;
searchResults.innerHTML=`<div style="padding:10px;background:#d1fae5;border-radius:6px;color:#065f46">Dipilih: <strong>${el.dataset.title}</strong></div>`;
}
</script>
</body>
</html>
