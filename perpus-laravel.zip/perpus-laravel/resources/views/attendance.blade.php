<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/webp" href="/akti.webp">
<title>Buku Tamu Kunjungan | Perpus AKTI</title>
<style>
:root{--maroon-dark:#6B2E2E;--maroon:#8A2529;--maroon-light:#A42631;--white:#ffffff;--gray-50:#f9fafb;--gray-100:#f3f4f6;--gray-200:#e5e7eb;--gray-600:#4b5563;--gray-900:#111827;--green:#10b981}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--gray-50);color:var(--gray-900);line-height:1.6}
header{background:linear-gradient(135deg,var(--maroon-dark) 0%,var(--maroon) 50%,var(--maroon-light) 100%);color:var(--white);padding:20px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 12px rgba(107,46,46,0.15)}
.brand{display:flex;align-items:center;gap:16px}
.brand img{height:48px;width:auto}
.brand-text{display:flex;flex-direction:column}
.brand-text strong{font-size:20px;letter-spacing:0.5px}
.brand-text small{font-size:13px;opacity:0.9}
.header-right{display:flex;align-items:center;gap:16px}
main{max-width:1100px;margin:0 auto;padding:32px 24px}
.page-title{font-size:28px;font-weight:700;margin-bottom:24px;color:var(--gray-900);text-align:center}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
.card{background:var(--white);border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);padding:28px;margin-bottom:24px}
.card-header{display:flex;align-items:center;gap:12px;margin-bottom:20px}
.card-title{font-size:20px;font-weight:700;color:var(--gray-900)}
label{display:block;font-weight:600;margin-bottom:6px;font-size:14px}
input,select{width:100%;padding:12px;border:1px solid var(--gray-200);border-radius:6px;font-size:15px;margin-bottom:16px}
input:focus,select:focus{outline:none;border-color:var(--maroon);box-shadow:0 0 0 3px rgba(138,37,41,0.1)}
.btn{padding:12px 18px;border:none;border-radius:6px;font-weight:600;font-size:15px;cursor:pointer;transition:all 0.2s;width:100%}
.btn-primary{background:var(--maroon);color:var(--white)}
.btn-primary:hover{background:var(--maroon-light)}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:12px;border-bottom:1px solid var(--gray-200)}
th{background:var(--gray-50);font-weight:600;font-size:13px;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-600)}
.badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;background:#d1fae5;color:#065f46}
.notice{background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
.error{background:#fee2e2;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
.biodata-panel{background:linear-gradient(135deg,#f0fdf4 0%,#dcfce7 100%);border:2px solid var(--green);border-radius:8px;padding:16px;margin-bottom:16px}
.biodata-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:8px}
.biodata-item{display:flex;flex-direction:column}
.biodata-label{font-size:11px;color:var(--gray-600);font-weight:600;text-transform:uppercase;letter-spacing:0.5px}
.biodata-value{font-size:14px;color:var(--gray-900);font-weight:600}
</style>
</head>
<body>
<header>
<div class="brand">
<img src="/akti.webp" alt="AKTI">
<div class="brand-text">
<strong>PERPUSTAKAAN AKTI</strong>
<small>Buku Tamu Kunjungan</small>
</div>
</div>
<div class="header-right">
<a href="{{ route('login') }}" style="color:rgba(255,255,255,0.7);font-size:12px;text-decoration:none;padding:6px 12px;border:1px dashed rgba(255,255,255,0.3);border-radius:4px" title="Login Khusus Pustakawan">🔒 Login Admin</a>
</div>
</header>

<main>
<h1 class="page-title">🚪 Buku Tamu Kunjungan Perpustakaan AKTI</h1>

@if(session('success'))
<div class="notice">{{ session('success') }}</div>
@endif
@if($errors->any())
<div class="error">{{ $errors->first() }}</div>
@endif

<div class="grid">
<div class="card">
<div class="card-header">
<h2 class="card-title">📝 Check-In Kunjungan</h2>
</div>
<form method="post" action="{{ route('attendance.store') }}">
@csrf
<label>NIM Mahasiswa</label>
<input id="nimInput" name="nim" autocomplete="off" placeholder="Ketik NIM (contoh: 3265301)" maxlength="10" required>

<div id="biodataPanel" class="biodata-panel" style="display:none">
<div style="font-size:15px;font-weight:700;color:var(--green);margin-bottom:4px">✓ Mahasiswa Ditemukan</div>
<div class="biodata-grid">
<div class="biodata-item"><span class="biodata-label">Nama Lengkap</span><span class="biodata-value" id="bioName">-</span></div>
<div class="biodata-item"><span class="biodata-label">NIM</span><span class="biodata-value" id="bioNim">-</span></div>
<div class="biodata-item"><span class="biodata-label">WhatsApp</span><span class="biodata-value" id="bioPhone">-</span></div>
<div class="biodata-item"><span class="biodata-label">Grup Belajar</span><span class="biodata-value" id="bioGroup">-</span></div>
</div>
</div>

<label>Tujuan Kunjungan</label>
<select name="purpose" required>
<option value="">Pilih Tujuan</option>
<option value="Membaca Buku / Belajar">Membaca Buku / Belajar</option>
<option value="Meminjam / Mengembalikan Buku">Meminjam / Mengembalikan Buku</option>
<option value="Mengerjakan Tugas / Diskusi Kelompok">Mengerjakan Tugas / Diskusi Kelompok</option>
<option value="Menggunakan Komputer / Internet">Menggunakan Komputer / Internet</option>
<option value="Lainnya">Lainnya</option>
</select>

<button class="btn btn-primary">Check-In Kunjungan</button>
</form>
</div>

<div class="card">
<div class="card-header">
<h2 class="card-title">📋 Rekap Kunjungan Hari Ini</h2>
</div>
<div style="max-height:480px;overflow:auto">
<table>
<thead>
<tr>
<th>Waktu</th>
<th>Mahasiswa</th>
<th>Tujuan</th>
</tr>
</thead>
<tbody>
@forelse($attendances as $att)
@if($att->created_at->isToday())
<tr>
<td><small style="color:#6b7280">{{ $att->created_at->format('H:i') }}</small></td>
<td><strong>{{ $att->user->name }}</strong><br><small style="color:#6b7280">{{ $att->user->nim }} • {{ $att->user->grup_belajar ?? '-' }}</small></td>
<td>{{ $att->purpose }}</td>
</tr>
@endif
@empty
<tr><td colspan="3" style="text-align:center;padding:24px;color:#6b7280">Belum ada kunjungan</td></tr>
@endforelse
</tbody>
</table>
</div>
</div>
</div>
</main>

<script>
const nimInput=document.getElementById('nimInput');
const biodataPanel=document.getElementById('biodataPanel');
const bioName=document.getElementById('bioName');
const bioNim=document.getElementById('bioNim');
const bioPhone=document.getElementById('bioPhone');
const bioGroup=document.getElementById('bioGroup');

let t;
nimInput?.addEventListener('input',()=>{
clearTimeout(t);
let nim=nimInput.value.trim();
if(!nim){biodataPanel.style.display='none';return;}
t=setTimeout(async()=>{
try{
let res=await fetch(`/users/search-nim?nim=${encodeURIComponent(nim)}`);
if(!res.ok){biodataPanel.style.display='none';return;}
let user=await res.json();
biodataPanel.style.display='block';
bioName.innerText = user.name;
bioNim.innerText = user.nim;
bioPhone.innerText = user.phone;
bioGroup.innerText = user.grup_belajar || '-';
}catch(e){biodataPanel.style.display='none';}
},200);
});
</script>
</body>
</html>
