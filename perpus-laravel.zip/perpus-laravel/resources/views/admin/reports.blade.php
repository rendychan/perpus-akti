<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/webp" href="/akti.webp">
<title>Rekap Bulanan | Perpus AKTI</title>
<style>
:root{--maroon-dark:#6B2E2E;--maroon:#8A2529;--maroon-light:#A42631;--white:#ffffff;--gray-50:#f9fafb;--gray-100:#f3f4f6;--gray-200:#e5e7eb;--gray-600:#4b5563;--gray-900:#111827;--green:#10b981;--blue:#3b82f6}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--gray-50);color:var(--gray-900);line-height:1.6}
header{background:linear-gradient(135deg,var(--maroon-dark) 0%,var(--maroon) 50%,var(--maroon-light) 100%);color:var(--white);padding:20px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 12px rgba(107,46,46,0.15)}
.brand{display:flex;align-items:center;gap:16px}
.brand img{height:48px;width:auto}
.brand-text{display:flex;flex-direction:column}
.brand-text strong{font-size:20px;letter-spacing:0.5px}
.brand-text small{font-size:13px;opacity:0.9}
.header-right{display:flex;align-items:center;gap:16px}
.btn-back{background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s}
.btn-back:hover{background:rgba(255,255,255,0.3)}
main{max-width:1200px;margin:0 auto;padding:32px 24px}
.page-title{font-size:28px;font-weight:700;margin-bottom:24px;color:var(--gray-900)}
.card{background:var(--white);border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);padding:24px;margin-bottom:24px}
.filter-bar{display:flex;gap:12px;align-items:center;margin-bottom:20px;flex-wrap:wrap}
select,input{padding:10px;border:1px solid var(--gray-200);border-radius:6px;font-size:14px}
.btn{padding:10px 18px;border:none;border-radius:6px;font-weight:600;font-size:14px;cursor:pointer;transition:all 0.2s;text-decoration:none;display:inline-block}
.btn-primary{background:var(--maroon);color:var(--white)}
.btn-primary:hover{background:var(--maroon-light)}
.btn-excel{background:var(--green);color:var(--white)}
.btn-excel:hover{background:#059669}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:12px;border-bottom:1px solid var(--gray-200)}
th{background:var(--gray-50);font-weight:600;font-size:13px;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-600)}
.badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600}
.badge-success{background:#d1fae5;color:#065f46}
.badge-warning{background:#fef3c7;color:#92400e}
.badge-danger{background:#fee2e2;color:#991b1b}
</style>
</head>
<body>
<header>
<div class="brand">
<img src="/akti.webp" alt="AKTI">
<div class="brand-text">
<strong>PERPUSTAKAAN AKTI</strong>
<small>Rekapitulasi Bulanan</small>
</div>
</div>
<div class="header-right">
<a href="{{ route('dashboard') }}" class="btn-back">← Dashboard</a>
</div>
</header>

<main>
<h1 class="page-title">📈 Rekap Bulanan & Export Excel</h1>

<div class="card">
<form method="get" action="{{ route('admin.reports') }}" class="filter-bar">
<div>
<label style="font-size:12px;font-weight:600;margin-bottom:4px">Jenis Rekap</label>
<select name="type">
<option value="attendance" {{ $type == 'attendance' ? 'selected' : '' }}>Rekap Kunjungan (Buku Tamu)</option>
<option value="loans" {{ $type == 'loans' ? 'selected' : '' }}>Rekap Peminjaman Buku</option>
</select>
</div>
<div>
<label style="font-size:12px;font-weight:600;margin-bottom:4px">Bulan</label>
<select name="month">
@for($m=1; $m<=12; $m++)
<option value="{{ $m }}" {{ $month == $m ? 'selected' : '' }}>{{ date('F', mktime(0, 0, 0, $m, 1)) }}</option>
@endfor
</select>
</div>
<div>
<label style="font-size:12px;font-weight:600;margin-bottom:4px">Tahun</label>
<select name="year">
@for($y=date('Y'); $y>=2024; $y--)
<option value="{{ $y }}" {{ $year == $y ? 'selected' : '' }}>{{ $y }}</option>
@endfor
</select>
</div>
<div style="align-self:flex-end">
<button class="btn btn-primary">Filter Data</button>
<a href="{{ route('admin.reports.export', ['type' => $type, 'month' => $month, 'year' => $year]) }}" class="btn btn-excel">📥 Download Excel (CSV)</a>
</div>
</form>

<div style="max-height:500px;overflow:auto">
<table>
<thead>
<tr>
@if($type === 'loans')
<th>ID</th>
<th>Mahasiswa</th>
<th>NIM</th>
<th>Grup</th>
<th>Buku</th>
<th>Tanggal Pinjam</th>
<th>Jatuh Tempo</th>
<th>Status</th>
@else
<th>ID</th>
<th>Waktu Kunjungan</th>
<th>Mahasiswa</th>
<th>NIM</th>
<th>Grup</th>
<th>Tujuan Kunjungan</th>
@endif
</tr>
</thead>
<tbody>
@forelse($data as $row)
<tr>
@if($type === 'loans')
<td>{{ $row->id }}</td>
<td><strong>{{ $row->user->name ?? '-' }}</strong></td>
<td>{{ $row->user->nim ?? '-' }}</td>
<td><span class="badge badge-success">{{ $row->user->grup_belajar ?? '-' }}</span></td>
<td>{{ $row->book->title ?? '-' }} <br><small style="color:#6b7280">{{ $row->book->code ?? '-' }}</small></td>
<td>{{ $row->borrowed_at->format('d M Y') }}</td>
<td>{{ $row->due_at->format('d M Y') }}</td>
<td>
@if($row->status === 'dikembalikan')
<span class="badge badge-success">Dikembalikan</span>
@elseif($row->due_at < today())
<span class="badge badge-danger">Terlambat</span>
@else
<span class="badge badge-warning">Dipinjam</span>
@endif
</td>
@else
<td>{{ $row->id }}</td>
<td>{{ $row->created_at->format('d M Y H:i') }}</td>
<td><strong>{{ $row->user->name ?? '-' }}</strong></td>
<td>{{ $row->user->nim ?? '-' }}</td>
<td><span class="badge badge-success">{{ $row->user->grup_belajar ?? '-' }}</span></td>
<td>{{ $row->purpose }}</td>
@endif
</tr>
@empty
<tr><td colspan="8" style="text-align:center;padding:32px;color:#6b7280">Tidak ada data rekap untuk bulan ini</td></tr>
@endforelse
</tbody>
</table>
</div>
</div>
</main>
</body>
</html>
