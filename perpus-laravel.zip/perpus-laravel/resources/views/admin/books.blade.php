<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/webp" href="/akti.webp">
<title>Manajemen Buku | Perpus AKTI</title>
<style>
:root{--maroon-dark:#6B2E2E;--maroon:#8A2529;--maroon-light:#A42631;--white:#ffffff;--gray-50:#f9fafb;--gray-100:#f3f4f6;--gray-200:#e5e7eb;--gray-600:#4b5563;--gray-900:#111827;--green:#10b981;--blue:#3b82f6}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--gray-50);color:var(--gray-900);line-height:1.6}
header{background:linear-gradient(135deg,var(--maroon-dark) 0%,var(--maroon) 50%,var(--maroon-light) 100%);color:var(--white);padding:20px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 12px rgba(107,46,46,0.15)}
.brand{display:flex;align-items:center;gap:16px}
.brand img{height:48px;width:auto}
.brand-text{display:flex;flex-direction:column}
.brand-text strong{font-size:20px;letter-spacing:0.5px}
.brand-text small{font-size:13px;opacity:0.9}
.header-right{display:flex;align-items:center;gap:16px}
.btn-back{background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s}
.btn-back:hover{background:rgba(255,255,255,0.3)}
main{max-width:1200px;margin:0 auto;padding:32px 24px}
.page-title{font-size:28px;font-weight:700;margin-bottom:24px;color:var(--gray-900)}
.grid{display:grid;grid-template-columns:1fr 2fr;gap:24px}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
.card{background:var(--white);border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);padding:24px;margin-bottom:24px}
.card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px}
.card-title{font-size:18px;font-weight:700;color:var(--gray-900)}
label{display:block;font-weight:600;margin-bottom:6px;font-size:14px}
input,select{width:100%;padding:10px;border:1px solid var(--gray-200);border-radius:6px;font-size:14px;margin-bottom:16px}
input:focus,select:focus{outline:none;border-color:var(--maroon);box-shadow:0 0 0 3px rgba(138,37,41,0.1)}
.btn{padding:8px 14px;border:none;border-radius:6px;font-weight:600;font-size:13px;cursor:pointer;transition:all 0.2s}
.btn-primary{background:var(--maroon);color:var(--white);width:100%;padding:10px;font-size:14px}
.btn-primary:hover{background:var(--maroon-light)}
.btn-edit{background:var(--blue);color:var(--white)}
.btn-edit:hover{background:#2563eb}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:12px;border-bottom:1px solid var(--gray-200)}
th{background:var(--gray-50);font-weight:600;font-size:13px;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-600)}
.badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;background:#d1fae5;color:#065f46}
.notice{background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
.error{background:#fee2e2;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
.filter-bar{display:flex;gap:12px;align-items:center;margin-bottom:16px}
</style>
</head>
<body>
<header>
<div class="brand">
<img src="/akti.webp" alt="AKTI">
<div class="brand-text">
<strong>PERPUSTAKAAN AKTI</strong>
<small>Manajemen Buku</small>
</div>
</div>
<div class="header-right">
<a href="{{ route('dashboard') }}" class="btn-back">← Dashboard</a>
</div>
</header>

<main>
<h1 class="page-title">📚 Manajemen Buku & Lokasi Rak</h1>

@if(session('success'))
<div class="notice">{{ session('success') }}</div>
@endif
@if($errors->any())
<div class="error">{{ $errors->first() }}</div>
@endif

<div class="grid">
<div class="card">
<div class="card-header">
<h2 class="card-title" id="formTitle">➕ Tambah Buku Baru</h2>
</div>
<form id="bookForm" method="post" action="{{ route('admin.books.store') }}">
@csrf
<input type="hidden" name="_method" id="formMethod" value="POST">
<label>Kode Buku</label>
<input id="bookCode" name="code" placeholder="Contoh: BK-IOT-005" required>
<label>Judul Buku</label>
<input id="bookTitle" name="title" placeholder="Judul buku" required>
<label>Pengarang</label>
<input id="bookAuthor" name="author" placeholder="Nama pengarang">
<label>Kategori</label>
<select id="bookCat" name="category_id" required>
<option value="">Pilih Kategori</option>
@foreach($categories as $cat)
<option value="{{ $cat->id }}">{{ $cat->name }} ({{ $cat->code }})</option>
@endforeach
</select>
<label>Lokasi Rak</label>
<input id="bookRack" name="rack_location" placeholder="Contoh: Rak A-03">
<label>Jumlah Stok / Eksemplar</label>
<input id="bookStock" type="number" name="stock" min="1" value="3" required>
<button type="submit" class="btn btn-primary" id="submitBtn">Simpan Buku</button>
<button type="button" class="btn" style="background:#e5e7eb;color:#374151;width:100%;margin-top:8px;display:none" id="cancelBtn" onclick="resetForm()">Batal Edit</button>
</form>
</div>

<div class="card">
<div class="card-header">
<h2 class="card-title">📋 Daftar Buku ({{ $books->count() }})</h2>
</div>

<div class="filter-bar">
<form method="get" action="{{ route('admin.books') }}" style="display:flex;gap:8px;width:100%">
<select name="rack" onchange="this.form.submit()" style="margin-bottom:0">
<option value="">-- Filter Semua Rak --</option>
@foreach($racks as $r)
<option value="{{ $r }}" {{ $rack == $r ? 'selected' : '' }}>{{ $r }}</option>
@endforeach
</select>
@if($rack)
<a href="{{ route('admin.books') }}" class="btn" style="background:#e5e7eb;color:#374151;display:flex;align-items:center;text-decoration:none">Reset</a>
@endif
</form>
</div>

<div style="max-height:450px;overflow:auto">
<table>
<thead>
<tr>
<th>Kode & Judul</th>
<th>Kategori</th>
<th>Rak</th>
<th>Stok</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>
@foreach($books as $book)
<tr>
<td><strong>{{ $book->title }}</strong><br><small style="color:#6b7280">{{ $book->code }} • {{ $book->author }}</small></td>
<td>{{ $book->category->name ?? '-' }}</td>
<td><span class="badge">📍 {{ $book->rack_location ?? 'Umum' }}</span></td>
<td>{{ $book->available_stock }} / {{ $book->stock }}</td>
<td>
<button class="btn btn-edit" onclick="editBook({{ json_encode($book) }})">Edit</button>
</td>
</tr>
@endforeach
</tbody>
</table>
</div>
</div>
</div>
</main>

<script>
function editBook(book){
document.getElementById('formTitle').innerText = '✏️ Edit Buku: ' + book.code;
document.getElementById('bookForm').action = '/admin/books/' + book.id;
document.getElementById('formMethod').value = 'PUT';
document.getElementById('bookCode').value = book.code;
document.getElementById('bookTitle').value = book.title;
document.getElementById('bookAuthor').value = book.author || '';
document.getElementById('bookCat').value = book.category_id;
document.getElementById('bookRack').value = book.rack_location || '';
document.getElementById('bookStock').value = book.stock;
document.getElementById('submitBtn').innerText = 'Update Buku';
document.getElementById('cancelBtn').style.display = 'block';
window.scrollTo({top:0, behavior:'smooth'});
}
function resetForm(){
document.getElementById('formTitle').innerText = '➕ Tambah Buku Baru';
document.getElementById('bookForm').action = '{{ route("admin.books.store") }}';
document.getElementById('formMethod').value = 'POST';
document.getElementById('bookForm').reset();
document.getElementById('submitBtn').innerText = 'Simpan Buku';
document.getElementById('cancelBtn').style.display = 'none';
}
</script>
</body>
</html>
