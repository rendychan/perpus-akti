<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/webp" href="/akti.webp">
<title>Manajemen Mahasiswa | Perpus AKTI</title>
<style>
:root{--maroon-dark:#6B2E2E;--maroon:#8A2529;--maroon-light:#A42631;--white:#ffffff;--gray-50:#f9fafb;--gray-100:#f3f4f6;--gray-200:#e5e7eb;--gray-600:#4b5563;--gray-900:#111827;--green:#10b981}
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--gray-50);color:var(--gray-900);line-height:1.6}
header{background:linear-gradient(135deg,var(--maroon-dark) 0%,var(--maroon) 50%,var(--maroon-light) 100%);color:var(--white);padding:20px 32px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 4px 12px rgba(107,46,46,0.15)}
.brand{display:flex;align-items:center;gap:16px}
.brand img{height:48px;width:auto}
.brand-text{display:flex;flex-direction:column}
.brand-text strong{font-size:20px;letter-spacing:0.5px}
.brand-text small{font-size:13px;opacity:0.9}
.header-right{display:flex;align-items:center;gap:16px}
.btn-back{background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.3);color:var(--white);padding:8px 16px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px;transition:all 0.2s}
.btn-back:hover{background:rgba(255,255,255,0.3)}
main{max-width:1200px;margin:0 auto;padding:32px 24px}
.page-title{font-size:28px;font-weight:700;margin-bottom:24px;color:var(--gray-900)}
.grid{display:grid;grid-template-columns:1fr 2fr;gap:24px}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
.card{background:var(--white);border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);padding:24px;margin-bottom:24px}
.card-header{display:flex;align-items:center;gap:12px;margin-bottom:20px}
.card-title{font-size:18px;font-weight:700;color:var(--gray-900)}
label{display:block;font-weight:600;margin-bottom:6px;font-size:14px}
input,select{width:100%;padding:10px;border:1px solid var(--gray-200);border-radius:6px;font-size:14px;margin-bottom:16px}
input:focus,select:focus{outline:none;border-color:var(--maroon);box-shadow:0 0 0 3px rgba(138,37,41,0.1)}
.btn{padding:10px 18px;border:none;border-radius:6px;font-weight:600;font-size:14px;cursor:pointer;transition:all 0.2s}
.btn-primary{background:var(--maroon);color:var(--white);width:100%}
.btn-primary:hover{background:var(--maroon-light)}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:12px;border-bottom:1px solid var(--gray-200)}
th{background:var(--gray-50);font-weight:600;font-size:13px;text-transform:uppercase;letter-spacing:0.5px;color:var(--gray-600)}
.badge{display:inline-block;padding:4px 10px;border-radius:12px;font-size:12px;font-weight:600;background:#d1fae5;color:#065f46}
.notice{background:#d1fae5;color:#065f46;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
.error{background:#fee2e2;color:#991b1b;padding:12px 16px;border-radius:8px;margin-bottom:16px;font-size:14px}
</style>
</head>
<body>
<header>
<div class="brand">
<img src="/akti.webp" alt="AKTI">
<div class="brand-text">
<strong>PERPUSTAKAAN AKTI</strong>
<small>Manajemen Mahasiswa</small>
</div>
</div>
<div class="header-right">
<a href="{{ route('dashboard') }}" class="btn-back">← Dashboard</a>
</div>
</header>

<main>
<h1 class="page-title">🎓 Manajemen Mahasiswa</h1>

@if(session('success'))
<div class="notice">{{ session('success') }}</div>
@endif
@if($errors->any())
<div class="error">{{ $errors->first() }}</div>
@endif

<div class="grid">
<div class="card">
<div class="card-header">
<h2 class="card-title">➕ Tambah Mahasiswa</h2>
</div>
<form method="post" action="{{ route('admin.students.store') }}">
@csrf
<label>Nama Lengkap</label>
<input name="name" placeholder="Nama mahasiswa" required>
<label>NIM (Nomor Induk)</label>
<input name="nim" placeholder="Contoh: 3265363" required>
<label>Nomor WhatsApp</label>
<input name="phone" placeholder="0812..." required>
<label>Grup Belajar</label>
<input name="grup_belajar" placeholder="Contoh: Kelompok A">
<label>Email</label>
<input type="email" name="email" placeholder="mahasiswa@akti.test" required>
<label>Password</label>
<input type="password" name="password" value="password" required>
<button class="btn btn-primary">Simpan Mahasiswa</button>
</form>
</div>

<div class="card">
<div class="card-header">
<h2 class="card-title">📋 Daftar Mahasiswa ({{ $students->count() }})</h2>
</div>
<div style="max-height:500px;overflow:auto">
<table>
<thead>
<tr>
<th>Nama & NIM</th>
<th>WhatsApp</th>
<th>Grup</th>
</tr>
</thead>
<tbody>
@foreach($students as $student)
<tr>
<td><strong>{{ $student->name }}</strong><br><small style="color:#6b7280">NIM: {{ $student->nim }}</small></td>
<td>{{ $student->phone }}</td>
<td><span class="badge">{{ $student->grup_belajar ?? '-' }}</span></td>
</tr>
@endforeach
</table>
</div>
</div>
</div>
</main>
</body>
</html>
