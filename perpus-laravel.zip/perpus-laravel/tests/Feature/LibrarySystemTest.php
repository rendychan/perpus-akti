<?php

namespace Tests\Feature;

use App\Models\Book;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class LibrarySystemTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_can_open_login_page(): void
    {
        $this->get('/login')
            ->assertOk()
            ->assertSee('Masuk Perpustakaan');
    }

    public function test_authenticated_user_can_search_books_by_title(): void
    {
        $user = User::factory()->create(['role' => 'mahasiswa']);
        Book::create(['code' => 'BK-IOT-001', 'title' => 'Internet of Things', 'stock' => 2, 'available_stock' => 2]);

        $this->actingAs($user)
            ->getJson('/books/search?q=i')
            ->assertOk()
            ->assertJsonFragment(['title' => 'Internet of Things']);
    }
}
